// erik video url: https://WWW.youtube.com/watch?v=AvNTu0uZmzY

/*
01110110 01100001 01100011 01110101 01110101 01101101   
01100011 01101111 01100100 01100101 00100000 01110011 01100011 01110010 01101001 01110100 01110100 01101111
00100000 01100100 01100001 00100000 01101100 01110101 01100011 01100001 00100000 01100101 00100000 01100100
01101111 01100011 00100000 01100011 00101100 0001010 01100001 01101110 01101110 01101111 00100000 00110010
00110000 00110001 00111001 00101100 0001010
*/
//                        _____   _    _   _    _   ___    ___
//     \\    //   //\\   |  ___| | |  | | | |  | | |   \  /   |
//      \\  //   //__\\  | |___  | |__| | | |__| | | |\ \/ /| |
//       \\//   //    \\ |_____| |______| |______| |_| \__/ |_|
//
// TODO:
//    a) we need to change/fix the 'clawstate' logic.
//
// Changelog (for Luca!)
//   2/18/2019
//    1) made up gantry piu sforza than down gantry ..more resistance
//    2) put on a stall current on the gantry to keep it from drifrting down
//    3) redid logic of the gantry limit switches.
//    4) redid the auton drive speed -vs- the regular drive speed.
//
#include <iostream>
#include <memory>
#include <string>
#include <thread>
#include <vector>
#include <math.h>
#include <time.h>
#include <frc/Joystick.h>
#include <frc/PWMVictorSPX.h>
#include <frc/drive/DifferentialDrive.h>
#include <frc/livewindow/LiveWindow.h>
#include <cameraserver/CameraServer.h>
#include <frc/WPILib.h>
// #include <unistd.h>
#include <frc/TimedRobot.h>
#include <frc/smartdashboard/SmartDashboard.h>
#include <frc/DoubleSolenoid.h>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/core/core.hpp>
#include <frc/Encoder.h>
#include <frc/AnalogInput.h>
#include <frc/DigitalInput.h>
#include <frc/DigitalOutput.h>
#include <frc/XboxController.h>
#include <frc/BuiltInAccelerometer.h>
#include <frc/Servo.h>
#include <frc/ADXRS450_Gyro.h>
#include <frc/AnalogGyro.h>
#include <frc/SPI.h>
#include <frc/Encoder.h>


//**********************************************DEFINE************************************************
class Robot : public frc::TimedRobot
{
 //vision_____________________________________
private:
 static void VisionThread()
 {
  //  cs::UsbCamera camera = frc::CameraServer::GetInstance()->StartAutomaticCapture(1);
  //  cs::UsbCamera camera2 = frc::CameraServer::GetInstance()->StartAutomaticCapture(2);
  //  camera.SetResolution(640, 480);
  //  camera2.SetResolution(640, 480);
  //  camera.SetResolution(320,240);
  //  camera2.SetResolution(320,240);
  //  camera.SetBrightness(1);
  //  cs::CvSink cvSink = frc::CameraServer::GetInstance()->GetVideo();
  //  cs::CvSink cvSink1 = frc::CameraServer::GetInstance()->GetVideo();
  //  cs::CvSource outputStreamStd = frc::CameraServer::GetInstance()->PutVideo("RVid", 640, 480);
  //  cv::Mat source;
  //   cs::CvSource outputStreamStd1 = frc::CameraServer::GetInstance()->PutVideo("RVid", 640, 480);
  //  cv::Mat output;
  //  while (true)
  //  {
  //    cvSink.GrabFrame(source);
  //    cvtColor(source, output, cv::COLOR_BGR2GRAY);
  //    outputStreamStd.PutFrame(output);
  //  }
  //  while (true)
  //  {
  //    cvSink.GrabFrame(source);
  //    cvtColor(source, output, cv::COLOR_BGR2GRAY);
  //    outputStreamStd.PutFrame(output);
    
  //  }
 }

 //motion__________________________
 frc::PWMVictorSPX m_right1{0};
 frc::PWMVictorSPX m_left1{1};
 // frc::PWMVictorSPX m_right2{0};
 // frc::PWMVictorSPX m_left2{1};
  frc::SpeedControllerGroup m_left{m_left1, m_left2};
 // frc::SpeedControllerGroup m_right{m_right2, m_right1};
 frc::DifferentialDrive m_robotDrive{m_right1, m_left1};

 // camera and servo ________________________
 frc::Servo cameraSlew{2};
 frc::PWMVictorSPX clawMotor{6};
 frc::PWMVictorSPX clawRotator{9};
 frc::LiveWindow &m_lw = *frc::LiveWindow::GetInstance();
 frc::Timer m_timer;
 cs::UsbCamera camera1;
 cs::UsbCamera camera2;

 
 frc::PWMVictorSPX rarmTrack{5};
 frc::PWMVictorSPX larmTrack{4};
 frc::PWMVictorSPX elevator{3};
 frc::Encoder elevatorTravel{6, 7};
 frc::Encoder clawTravel{8, 9}; 

 // joystick________________________________________
 frc::Joystick m_stickl{0};
 frc::Joystick m_stickr{1};
 frc::XboxController controller1{2};
 frc::Joystick yaxis{2};

 // analog input _____________________________
 frc::AnalogInput lightreceiver{0};
 // frc::AnalogInput SetOversampleBits();
 // frc::AnalogInput SetAverageBits();
 // frc::AnalogInput SetSampleRate();
  // digital input________________________________
 frc::DigitalInput lSwitch{0};
 frc::DigitalInput clawlimit{4};
 frc::DigitalInput clawRotatorlimit{2};
 frc::DigitalInput elevlimit{3};

 // digital output_______________________________________
 frc::DigitalOutput light1{5};
 frc::DigitalOutput LED1{1};
 // soleoid upforword _______________________________________-
 frc::DoubleSolenoid m_doubleSolenoidForward{0, 1}; // double action solenoid Pnuemo
 frc::DoubleSolenoid m_doubleSolenoidBack{2, 3};
  // gyro and accel____________________________________
 frc::AnalogGyro gyro1{3};
 // frc::BuiltInAccelerometer accel;
 // frc::ADXRS450_Gyro gyrocamera{};
 

public:
// controller_______________________________
enum class Button {
   kBumperLeft = 5,
   kBumperRight = 6,
   kStickLeft = 9,
   kStickRight = 10,
   kA = 1,
   kB = 2,
   kX = 3,
   kY = 4,
   kBack = 7,
   kStar= 8
   };
 bool prevTrigger = false;
 float RightaxisXValue;
 float lDrive = 0, rDrive = 0, temp, driveSpeed, driveSpeed0, autonDrive, r; //direve
 int limitswitch = 0, elevatorEncoderCount , encoderClaw_base, encoderClaw;
 int rawVal, rawAvg, bits; // DEFNS : Analog read
 int lDis = 16, rDis = 13, count = 0, countAUTO, j; //outputs
 bool armout, armin, clawstate,clawRotator_state, clawUp, clawDown;
 bool flagLED = false;
 bool liftForward, liftBack, changeBoth, camDir_toggle=false; 
 bool upForward = 0, upBack = 0; //solenoid
 bool dumm, tiltdum = 0, tilter, flagElev, flagElev_last, elevOn;
 bool mainArmDir, armMotorBackward, armMotorForward, speedSwitch;
 double angleTurn = 0.0;
 double angleRate = 0.0;
 double driftRate = 0.0;
 double RightaxisXvalue, elevation, elevatorSpeed, elevatorDir, elevatorDir_last, elev, deadBand, driveDir;
 double elevatorSpeedUp, elevatorSpeedDown, elevatorStall, PD_LEDon, PD_LEDoff, PDsignal;
 double Volts1, Volts1Avg, ai, clawSpeed, click1, click2, xVal, accval, armsDir, clawDir, clawDir_last; 
 double armspeedIn, armspeedOut, GetAngle, autoDrive[100],clawRotator_direction, clawRotator_dir_last, clawRotator_speed;
 //        analoginput.setoversamplebits(4);
 //*Analog0 setOversampleBits(4);
 //bits = Analog0->GetOversampleBits();
 //*Analog0 SetAverageBits(2);
 //bits = Analog0->GetAverageBits();

 void RobotInit()
 {
   camera1 = frc::CameraServer::GetInstance()->StartAutomaticCapture(0);
   camera2 = frc::CameraServer::GetInstance()->StartAutomaticCapture(1);
   camera2.SetBrightness(10);
   //std::thread visionThread(VisionThread);
   //visionThread.detach();
   // elev________________________________________
   elevatorTravel.Reset();                                       // reset the quadrature encoder on the gantry motor
   elevatorEncoderCount = 0;
   elevatorSpeedUp = 0.8;                                        // limit to elevator speed going up
   elevatorSpeedDown = 0.5;                                      // limit speed elevator going down
   elevatorStall = 0.12;                                          // stall to avoid drifting down on elevator
   driveSpeed0 = 1.0;                                            // max "fast and furious" driving
   autonDrive = 0.5*driveSpeed0;
   clawRotator_speed = 1.0;                                   // slip into slower motions....for auton
   deadBand = 0.1;                                   // how fast to rotate up and down the claw  
   encoderClaw_base  = -3250; 
   // cs::UsbCamera camera =frc::CameraServer::GetInstance()->StartAutomaticCapture(1);
   // cs::UsbCamera camera2 =frc::CameraServer::GetInstance()->StartAutomaticCapture(2);
   clawMotor.EnableDeadbandElimination(true);
   clawSpeed = 1.0;                                              // open and close claw speed
   larmTrack.EnableDeadbandElimination(true);
   armspeedIn = 0.3;                                             // arm gather motor speed to suck in
   armspeedOut = 1.0;                                            // arm gather motor speed to throw ball out
   rarmTrack.EnableDeadbandElimination(true);
   // gyro
   gyro1.Reset();
   gyro1.InitGyro();
   r = 0.2;                                                     // Analog signal averaging epoch = 1/r
   // initiqalize the autoDrive
   autoDrive[1] = 1000;   //TIME FOR
   autoDrive[2] = .4;       // DRIVE E
   autoDrive[3] = -.6;
   autoDrive[4] = 3000;
   autoDrive[5] = -1.0;
   autoDrive[6] = -1.0;
   autoDrive[7] = 1000;
   autoDrive[8] = -.6;
   autoDrive[9] = .4;
   autoDrive[10]= 5000;
   autoDrive[11]= 1.0;
   autoDrive[12]= 1.0;
   autoDrive[13] = 1000;   //TIME FOR
   autoDrive[14] = .4;       // DRIVE E
   autoDrive[15] = -.6;
   autoDrive[16] = 1000;
   autoDrive[17] = -1.0;
   autoDrive[18] = -1.0;
   autoDrive[19] = 1000;
   autoDrive[20] = -.6;
   autoDrive[21] = .4;
   autoDrive[22]= 1000;
   autoDrive[23]= 1.0;
   autoDrive[24]= 1.0;
   autoDrive[25]= 1000;
 }
 void AutonomousInit()                                          // Auton Section...may have to fill this in with drive code.
  {
  //  if(autonomousCommand != NULL) autonomousCommand->Start();
  }
  void AutonomousPeriodic()
  {  
  //  Scheduler::GetInstance()->Run();
frc::Scheduler::GetInstance()->Run();

    TeleopPeriodic();  
  }
 void TeleopPeriodic() override
 {
  
   count++; //counts reps through the teleop seqeunce
   // AutoDrive section
  //  sleep(1000);
   if (!m_stickr.GetRawButton(5)){
     j=1;
   }
   while((m_stickr.GetRawButton(5))&&(j<25)){
       m_robotDrive.ArcadeDrive(autoDrive[j+1]+autoDrive[j+2], autoDrive[j+1]-autoDrive[j+2]);
      //  sleep(autoDrive[j]/1000.0);
     j=j+3;
   }
  // end of AutoDrive section
  // arm gather motor section , and claw
    
    //  armMotorForward = controller1.GetBumper(frc::GenericHID::kRightHand);
    //  armMotorBackward = controller1.GetTriggerAxis(frc::GenericHID::kRightHand);
     armsDir=(double)(armMotorForward)*armspeedIn-(double)(armMotorBackward)*armspeedOut;
     rarmTrack.Set(armsDir); 
     larmTrack.Set(-armsDir);
  // end arm gather section
  // claw rotator secion 
    clawUp = controller1.GetAButton();
    clawDown = controller1.GetBButton();
    clawRotator_direction = -(double)(clawUp)*clawRotator_speed+(double)(clawDown)*clawRotator_speed; 
    clawRotator.Set(clawRotator_direction);
    //  clawRotator_direction =  controller1.GetY(frc::GenericHID::kRightHand)*clawRotator_speed;
    // END claw rotator section 
   // CLAW section
   clawDir=0.0;
  //  if (controller1.GetBumper(frc::GenericHID::kLeftHand))
  //  {
  //    clawDir = clawSpeed;
  //  }
  //  if (controller1.GetTriggerAxis(frc::GenericHID::kLeftHand)){
  //    clawDir= -clawSpeed;
  //  }
  //  if(clawstate==1){   //main claw motion
  //      clawMotor.Set(clawDir);
  //  }
   // END Claw section
   // Drive with arcade style
   if(!speedSwitch){
     driveSpeed = driveSpeed0;
   }
   else{
     driveSpeed = autonDrive;
   }
   if(!camDir_toggle){
     driveDir = driveSpeed;
   }
   else{
     driveDir = -driveSpeed;
   }
   lDrive = driveDir*m_stickr.GetY();
   rDrive = driveDir*m_stickl.GetY();
   if(driveDir<0.0){                             // when you turn around, what you call left adn right have to flip as well. 
     temp=lDrive;
     lDrive=rDrive;
     rDrive=temp;
   }  
   m_robotDrive.ArcadeDrive(lDrive + rDrive, lDrive - rDrive);
   // END Drive
    // elevator lift section
    flagElev=elevlimit.Get();    
    elevatorDir = -controller1.GetY(frc::GenericHID::kLeftHand);
    if (fabs(elevatorDir)<deadBand){
         elevatorSpeed = elevatorStall;
       }
    if(elevatorDir>deadBand){
         elevatorSpeed = elevatorSpeedUp+elevatorStall;
       }
    if(elevatorDir<-deadBand){
         elevatorSpeed = -elevatorSpeedDown+elevatorStall;
       }
    if((flagElev)&&(!flagElev_last)) {
       elevatorDir_last = elevatorDir;
    }
    if(flagElev){
       if((elevatorDir_last>deadBand)&&(elevatorDir>deadBand)){
            elevatorSpeed=elevatorStall;
       }
       if((elevatorDir_last<deadBand)&&(elevatorDir<deadBand)){
            elevatorSpeed=elevatorStall;
       }
    }
   flagElev_last = flagElev;                             
   // END elevator lift section
   // elevator Drive
   elevator.Set(elevatorSpeed);
   // END elevator drive
   if (count % 30 == 0)
   {// update button state every 30 times through teleop, (about 300 ms)
     // auton drive speed select
   /*  if (m_stickl.GetRawButton(5))
   {
     camera1 = frc::CameraServer::GetInstance()->StartAutomaticCapture(1);
     camera2 = frc::CameraServer::GetInstance()->StartAutomaticCapture(0);
   }*/
     speedSwitch = m_stickr.GetRawButton(1);
     clawstate= clawlimit.Get();
     if (clawDir!=clawDir_last){
       clawstate=true;
     }
     clawDir_last = clawDir;
   
     // END arm gather motor section , and claw
     // Pneumatic lift button section section
     liftForward = controller1.GetTriggerAxis(frc::GenericHID::kLeftHand);
     upForward = upForward^liftForward;
     liftBack = controller1.GetTriggerAxis(frc::GenericHID::kRightHand);
     upBack = upBack^liftBack;
     /*changeBoth = m_stickl.GetRawButton(2);
     if(changeBoth)
     {
       upBack = upBack^changeBoth;
       upForward = upForward^changeBoth;
     }*/
     // END Pneumatic button section
     // camera slew motor
     camDir_toggle = camDir_toggle^m_stickl.GetRawButton(1);
     if (camDir_toggle)
     {
     cameraSlew.Set(.5);
     cameraSlew.SetAngle(180);
     }
     else{
     cameraSlew.Set(.5);
     cameraSlew.SetAngle(0);
     }
     //END Camera slew
     // gaffers tape strip detect
     flagLED = !flagLED;                             //toggle the light each time through
     light1.Set(flagLED);
     if (!flagLED) {  // compare reading light on to light off
       PD_LEDon = (1.0-r)*PD_LEDon+r*(double)(lightreceiver.GetValue());
     }
     else {
       PD_LEDoff = (1.0-r)*PD_LEDoff+r*(double)(lightreceiver.GetValue());
     }
     PDsignal = PD_LEDon-PD_LEDoff;
     // END gaffers tape strip detect
    
     //Print Encoder Values
     frc::SmartDashboard::PutNumber("Right Encoder", dumm);
     frc::SmartDashboard::PutNumber("Left Joy", lDrive);
     frc::SmartDashboard::PutNumber("Rigth Joy", rDrive);
     frc::SmartDashboard::PutNumber("clawDir", clawDir);
     frc::SmartDashboard::PutNumber("armsDrive", armsDir);
     frc::SmartDashboard::PutNumber("VoltsAvg", Volts1Avg);
     frc::SmartDashboard::PutNumber("claw", clawlimit.Get());
     frc::SmartDashboard::PutNumber("Bumper State, Left", controller1.GetBumper(frc::GenericHID::kLeftHand));
     frc::SmartDashboard::PutNumber("Rcvr Off  Val", PD_LEDoff);
     frc::SmartDashboard::PutNumber("Claw rotator  Speed", clawRotator_direction);
     frc::SmartDashboard::PutNumber("elevMicro", flagElev);
     frc::SmartDashboard::PutNumber("elev speed", elevatorSpeed);
     frc::SmartDashboard::PutNumber("elevator encoder", elevatorTravel.Get());
     frc::SmartDashboard::PutNumber("claw encoder", clawTravel.Get());
     frc::SmartDashboard::PutNumber("j",j);
     
    
     // end of the (count % 30 == 0)
     //       Analog0 *ai;
     //        ai = new Analog0(0);
     // Analog Read section
     //rawVal = Analog0.GetValue();
     //Volts1 = Analog0.GetVoltage();
     //rawAvg = Analog0.GetAverageValue();
     //Volts1Avg = Analog0.GetAverageVoltage();

     // END Analog Read Section
     // Acceleration
     //accel = new builtinAccelerometer(Accelerometer:kRange_4G);
     //double xVal = accel.GetX();
     // double accval = gyrocamera.GetAngle();
     //    double yVal = accel->GetY();
     //    double zVal = accel->GetZ();
     // END Acceleration
     // Pneumatics
     if (upForward)
     {
       m_doubleSolenoidForward.Set(frc::DoubleSolenoid::kForward);
     }
     else
     {
       m_doubleSolenoidForward.Set(frc::DoubleSolenoid::kReverse);
     }
     if (upBack)
     {
       m_doubleSolenoidBack.Set(frc::DoubleSolenoid::kForward);
     }
     else
     {
       m_doubleSolenoidBack.Set(frc::DoubleSolenoid::kReverse);
     }
   }
 };  // end of TeleopPeriodic
// ***********************************************gyro
/*void OperatorControl() {
       gyro1.Reset();
       while (IsOperatorControl() && IsEnabled()) {
           if(m_stickr.GetRawButton(2)) {
               gyro1.Reset();
               driftRate = gyro1.GetAngle();
               frc::SmartDashboard::PutNumber("drift rate", driftRate);
           }
           angleTurn = gyro1.GetAngle();
           angleRate = gyro1.GetRate();
           frc::SmartDashboard::PutNumber("Gyro angle", angleTurn);
           frc::SmartDashboard::PutNumber("Rate of turning", angleRate);
       }
   }
   */
};    // end of Robot
//#ifndef RUNNING_FRC_TESTS
int main()
{
 return frc::StartRobot<Robot>();

}

/*   Hardware Map! 

PWM   
   0     Right Drive Motor
   1     Left Drive Motor
   2     camera slew motor
   3     elevator
   4     L arm gather wheels
   5     R arm gather wheels
   6     claw motor (open and closed)
   7     
   8     claw rotator motor
   9

DIO 

   0      <- Switch/for testing
   1      -> LED Illuminator
   2      <- clawRotator limit switch
   3      <- elevator limit switches
   4      <- claw limit
   5      -> light1
   6      <- A   encoder elev motor
   7      <- B     "" 
   8      <- claw encoder A
   9      <- claw encoder B 

ANALOGIN 
   0      Photodetector input 
   1
   2
   3      Analog Gyro 


USB
  USB Camera (x2)

joystickL                   JOYSTICKR
  1  drive dir/cam slew      1     
  2                          2
  3  PISTON FORWORD          3 PISTON BACKWORD           
  4
  5
  6
  7
  8
  9
*/