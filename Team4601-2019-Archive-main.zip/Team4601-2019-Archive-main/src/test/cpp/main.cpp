#include <iostream>

int main ()
{
  int jjjj;
  int result;
  int cup;

   >>




}

